
window.alert("Bienvenidxs a este sitio en construción 😃");

var script = document.createElement('button'); 


location.href('https://www.instagram.com/soldenoch3/')